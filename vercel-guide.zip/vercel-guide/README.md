# Guia Vercel

Componente React que mostra como publicar seu site com a Vercel.

## Como usar

1. Copie `VercelGuide.jsx` para seu projeto React.
2. Importe o componente:

```js
import VercelGuide from "./VercelGuide";
```

3. Use no seu JSX:

```jsx
<VercelGuide />
```

## Sobre

- Criado em: Agosto de 2025
- Conteúdo: Guia passo a passo para deploy na Vercel
